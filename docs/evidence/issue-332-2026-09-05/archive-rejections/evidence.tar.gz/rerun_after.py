from __future__ import annotations
from pathlib import Path
import hashlib,json,os,shutil,subprocess
B=Path('/tmp/leitir-remediation-20260905');W=B/'release-0.2.000';D=B/'release-evidence/ci-artifact-reject-review';O=B/'release-evidence/ci-33962193988-dist';env={k:v for k,v in os.environ.items() if k not in {'GH_TOKEN','GITHUB_TOKEN'}}
original_results=json.loads((D/'results.json').read_text())+json.loads((D/'additional-results.json').read_text())+[json.loads((D/'zlib-result.json').read_text())]
results=[]
for before in original_results:
 command=before['command'];case=Path(command[command.index('--dist')+1]);actual={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(case.iterdir())};expected=before.get('artifact_sha256')
 if expected is not None:assert actual==expected,(before['case'],'original mutation changed')
 elif before['case']=='wheel_invalid_deflate_metadata':assert actual['leitir-0.2.0-py3-none-any.whl']==before['sha256']
 p=subprocess.run(command,cwd=W,env=env,capture_output=True,text=True,timeout=30)
 row={'case':before['case'],'command':command,'before_exit':before['returncode'],'after_exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'traceback':'Traceback' in p.stderr,'artifact_sha256':actual};results.append(row)
 expected_accept=before['case'] in {'control_original','wheel_bad_crc'}
 assert p.returncode==(0 if expected_accept else 1),row
 assert 'Traceback' not in p.stderr,row
 assert expected_accept or p.stderr.startswith('release verification rejected:'),row
(D/'after-results.json').write_text(json.dumps(results,indent=2))
extra=[]
for kind in ['sdist_trailer_crc_corrupt','sdist_trailer_truncated']:
 case=D/kind;case.mkdir()
 for a in O.iterdir():shutil.copyfile(a,case/a.name)
 archive=case/'leitir-0.2.0.tar.gz';data=bytearray(archive.read_bytes())
 if kind.endswith('corrupt'):data[-8]^=1
 else:data=data[:-8]
 archive.write_bytes(data)
 command=['python',str(W/'tools/verify_release.py'),'--tag','v0.2.000','--dist',str(case),'--project',str(W/'pyproject.toml')]
 p=subprocess.run(command,cwd=W,env=env,capture_output=True,text=True,timeout=30)
 row={'case':kind,'command':command,'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'archive_sha256':hashlib.sha256(data).hexdigest()};extra.append(row)
 assert p.returncode==1 and p.stderr.startswith('release verification rejected:') and 'Traceback' not in p.stderr,row
(D/'trailer-results.json').write_text(json.dumps(extra,indent=2))
(D/'after-identities.json').write_text(json.dumps({'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip(),'tool_sha256':hashlib.sha256((W/'tools/verify_release.py').read_bytes()).hexdigest(),'project_sha256':hashlib.sha256((W/'pyproject.toml').read_bytes()).hexdigest(),'source_state':'Root uncommitted verifier corrections atop exact recorded head'},indent=2))
print(json.dumps({'existing_cases':len(results),'clean_rejections':sum(x['after_exit']==1 for x in results),'expected_valid_acceptances':sum(x['after_exit']==0 for x in results),'tracebacks':sum(x['traceback'] for x in results),'gzip_trailer_cases':extra},indent=2))
