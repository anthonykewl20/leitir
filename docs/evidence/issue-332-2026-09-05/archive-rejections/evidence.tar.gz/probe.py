from __future__ import annotations
import copy,hashlib,io,json,os,shutil,stat,subprocess,tarfile,warnings,zipfile
from pathlib import Path
B=Path('/tmp/leitir-remediation-20260905'); W=B/'release-0.2.000'; D=B/'release-evidence/ci-artifact-reject-review'; ORIGINAL=B/'release-evidence/ci-33962193988-dist'
HEAD=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip();assert HEAD=='cc134194e6528c34dd364d8a1dae15939093ed16'
N='leitir-0.2.0-py3-none-any.whl';T='leitir-0.2.0.tar.gz';M='leitir-0.2.0.dist-info/METADATA';P='leitir-0.2.0/PKG-INFO';J='leitir-0.2.0/pyproject.toml'
with zipfile.ZipFile(ORIGINAL/N) as z: BASE_META=z.read(M)
with tarfile.open(ORIGINAL/T) as t: BASE_PKG=t.extractfile(P).read();BASE_PROJECT=t.extractfile(J).read()
results=[]
def zmut(path,kind):
 with zipfile.ZipFile(ORIGINAL/N) as source,zipfile.ZipFile(path,'w') as dest:
  for item in source.infolist():
   data=source.read(item.filename);item=copy.copy(item)
   if item.filename==M:
    if kind=='missing':continue
    if kind=='wrong_name':data=data.replace(b'Name: leitir',b'Name: unrelated-project',1)
    elif kind=='duplicate_name':data=b'Name: unrelated-project\n'+data
    elif kind=='duplicate_version':data=b'Version: 9.9.9\n'+data
    elif kind=='duplicate_same_name':data=b'Name: leitir\n'+data
    elif kind=='oversize':data+=b'X'*(1024*1024+1)
    elif kind=='symlink_metadata':item.create_system=3;item.external_attr=(stat.S_IFLNK|0o777)<<16
   dest.writestr(item,data)
   if item.filename==M and kind=='duplicate_metadata':
    with warnings.catch_warnings():warnings.simplefilter('ignore',UserWarning);dest.writestr(item,data)
def tmut(path,kind):
 with tarfile.open(ORIGINAL/T,'r:gz') as source,tarfile.open(path,'w:gz') as dest:
  for original in source.getmembers():
   item=copy.copy(original);data=source.extractfile(original).read() if original.isfile() else None
   wanted=J if 'project' in kind else P
   if item.name==wanted:
    if kind.startswith('missing'):continue
    if kind=='wrong_name':data=data.replace(b'Name: leitir',b'Name: unrelated-project',1)
    elif kind=='duplicate_name':data=b'Name: unrelated-project\n'+data
    elif kind=='duplicate_version':data=b'Version: 9.9.9\n'+data
    elif kind=='oversize_pkg':data+=b'X'*(1024*1024+1)
    elif kind=='oversize_project':data+=b'\n#'+b'X'*(1024*1024+1)
    elif kind in {'symlink_pkg','symlink_project'}:item.type=tarfile.SYMTYPE;item.linkname='pyproject.toml' if wanted==P else 'PKG-INFO';data=None
    elif kind in {'hardlink_pkg','hardlink_project'}:item.type=tarfile.LNKTYPE;item.linkname=J if wanted==P else P;data=None
    elif kind=='wrong_project_name':data=data.replace(b'name = "leitir"',b'name = "unrelated-project"',1)
    elif kind=='project_list':data=b'project = ["leitir"]\n'
    elif kind=='project_string':data=b'project = "leitir"\n'
    elif kind=='missing_project_table':data=b'[build-system]\nrequires = []\n'
    elif kind=='malformed_project':data=b'[project\n'
    elif kind=='nonutf_project':data=b'\xff\xfe'+data
    item.size=len(data) if data is not None else 0
   dest.addfile(item,io.BytesIO(data) if data is not None else None)
   if item.name==wanted and kind in {'duplicate_pkg','duplicate_project'}:dest.addfile(item,io.BytesIO(data) if data is not None else None)
def run(label,mutation=None,archive=None):
 d=D/label;d.mkdir(exist_ok=False)
 for name in [N,T]:shutil.copyfile(ORIGINAL/name,d/name)
 if archive=='wheel':zmut(d/N,mutation)
 elif archive=='sdist':tmut(d/T,mutation)
 elif mutation=='symlink_artifact':(d/N).unlink();(d/N).symlink_to(ORIGINAL/N)
 elif mutation=='corrupt_wheel':(d/N).write_bytes((d/N).read_bytes()[:100])
 elif mutation=='corrupt_sdist':(d/T).write_bytes((d/T).read_bytes()[:100])
 elif mutation=='wheel_bad_crc':
  with zipfile.ZipFile(d/N) as z:info=z.getinfo('leitir/__init__.py');offset=info.header_offset+30+len(info.filename.encode())+len(info.extra)
  data=bytearray((d/N).read_bytes());data[offset]^=1;(d/N).write_bytes(data)
 command=['python',str(W/'tools/verify_release.py'),'--tag','v0.2.000','--dist',str(d),'--project',str(W/'pyproject.toml')]
 env={k:v for k,v in os.environ.items() if k not in {'GH_TOKEN','GITHUB_TOKEN'}}
 p=subprocess.run(command,cwd=W,env=env,capture_output=True,text=True,timeout=30)
 row={'case':label,'mutation':mutation,'archive':archive,'command':command,'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'traceback':'Traceback' in p.stderr,'artifact_sha256':{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(d.iterdir())}}
 results.append(row);(D/'results.json').write_text(json.dumps(results,indent=2))
run('control_original')
for kind in ['duplicate_metadata','missing','wrong_name','duplicate_name','duplicate_version','duplicate_same_name','oversize','symlink_metadata']:run('wheel_'+kind,kind,'wheel')
for kind in ['duplicate_pkg','duplicate_project','missing_pkg','missing_project','wrong_name','duplicate_name','duplicate_version','oversize_pkg','oversize_project','symlink_pkg','symlink_project','hardlink_pkg','hardlink_project','wrong_project_name','project_list','project_string','missing_project_table','malformed_project','nonutf_project']:run('sdist_'+kind,kind,'sdist')
for kind in ['symlink_artifact','corrupt_wheel','corrupt_sdist','wheel_bad_crc']:run(kind,kind)
identities={'source_head':HEAD,'source_head_end':subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip(),'source_tool_sha256':hashlib.sha256((W/'tools/verify_release.py').read_bytes()).hexdigest(),'original_artifacts':{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(ORIGINAL.iterdir())}}
(D/'identities.json').write_text(json.dumps(identities,indent=2));print(json.dumps([{'case':r['case'],'returncode':r['returncode'],'traceback':r['traceback'],'error':r['stderr'].splitlines()[-1] if r['stderr'] else None} for r in results],indent=2))
