from __future__ import annotations
import hashlib,json,os,signal,stat,subprocess,time
from datetime import datetime,timezone
from pathlib import Path
from leitir.materialize import read_valid_manifest
from leitir.treehash import verify_materialized_tree_hash
base=Path('/tmp/leitir-remediation-20260905'); work=base/'release-0.2.000'; out=base/'release-evidence/crash-recovery'; corpus=out/'corpus'
assert not corpus.exists(), 'fresh owned corpus required'
pin='85442b8032cb7bae72866dfd7782234a98dd2fb7'; spec='pypa/packaging#'+pin
parent=corpus/'repos/github.com/pypa/packaging'; target=parent/pin
start_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip()
secret=subprocess.check_output(['gh','auth','token'],text=True).strip()
env=dict(os.environ,PYTHONPATH=str(work/'src'),LEITIR_NO_UPDATE_CHECK='1',GITHUB_TOKEN=secret);env.pop('GH_TOKEN',None)
command=['python','-m','leitir.cli','get',spec,'--root',str(corpus),'--json']; events=[]; start=time.monotonic()
def event(kind,**kwargs):
 item={'event':kind,'elapsed_seconds':round(time.monotonic()-start,6),'utc':datetime.now(timezone.utc).isoformat(),**kwargs};events.append(item);(out/'events.json').write_text(json.dumps(events,indent=2))
def clean(text): return text.replace(secret,'[REDACTED]')
with (out/'killed.stdout').open('w') as stdout,(out/'killed.stderr').open('w') as stderr:
 process=subprocess.Popen(command,cwd=work,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
 event('cli_started',pid=process.pid,command=command,source_head=start_head)
 staging=None
 deadline=time.monotonic()+180
 while process.poll() is None and time.monotonic()<deadline:
  for path in parent.glob('.'+pin+'.tmp-*'):
   if any(p.is_file() and p.stat().st_size>0 for p in path.rglob('*')):
    os.kill(process.pid,signal.SIGSTOP);staging=path;event('sigstop_after_real_files_observed',staging=str(path));break
  if staging: break
  time.sleep(0.001)
 if staging is None:
  if process.poll() is None:os.killpg(process.pid,signal.SIGKILL)
  process.wait();event('stage_not_hit',exit=process.returncode)
  raise RuntimeError('Did not observe real populated staging; no crash proof claimed')
 time.sleep(0.02)
 files=[]
 for path in sorted(staging.rglob('*')):
  info=path.lstat()
  if stat.S_ISREG(info.st_mode):
   data=path.read_bytes();files.append({'path':path.relative_to(staging).as_posix(),'size':len(data),'sha256':hashlib.sha256(data).hexdigest()})
 incomplete_valid=read_valid_manifest(staging,'pypa','packaging',pin,host='github.com') is not None
 snapshot={'staging':str(staging),'files':files,'manifest_exists':(staging/'leitir-manifest.json').exists(),'valid_manifest':incomplete_valid,'published_target_exists':target.exists(),'sources_catalog_exists':(corpus/'sources.json').exists()}
 (out/'stopped-snapshot.json').write_text(json.dumps(snapshot,indent=2))
 event('stopped_snapshot',regular_files=len(files),valid_manifest=incomplete_valid,target_exists=target.exists())
 os.killpg(process.pid,signal.SIGKILL);process.wait(timeout=10);event('sigkill_completed',exit=process.returncode)
 assert files and not incomplete_valid and not target.exists(),snapshot
 for name in ['killed.stdout','killed.stderr']:
  p=out/name;p.write_text(clean(p.read_text()))
 event('normal_recovery_started')
 recovered=subprocess.run(command,cwd=work,env=env,capture_output=True,text=True,timeout=240)
 (out/'recovered.stdout').write_text(clean(recovered.stdout));(out/'recovered.stderr').write_text(clean(recovered.stderr))
 event('normal_recovery_completed',exit=recovered.returncode)
 assert recovered.returncode==0,clean(recovered.stderr)
 manifest=read_valid_manifest(target,'pypa','packaging',pin,host='github.com')
 assert manifest is not None and manifest['verified'] is True and manifest['parity']=='exact' and manifest['commit_sha']==pin,manifest
 (out/'final-manifest.json').write_text(json.dumps(manifest,indent=2))
 assert manifest['materialized_tree_hash_scope']=='full'
 remnants=[str(p) for p in parent.glob('.'+pin+'.tmp-*')]
 assert not remnants,remnants
 shared=[]
 for item in files:
  path=target/item['path']
  if path.is_file(): shared.append({'path':item['path'],'matches_recovered_source':hashlib.sha256(path.read_bytes()).hexdigest()==item['sha256']})
 assert any(x['matches_recovered_source'] for x in shared)
 final={'source_head_start':start_head,'source_head_end':subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip(),'spec':spec,'pin':pin,'killed_exit':process.returncode,'recovery_exit':recovered.returncode,'staging_files_at_kill':len(files),'incomplete_manifest_rejected':not incomplete_valid,'published_target_absent_after_kill':not snapshot['published_target_exists'],'stale_staging_after_recovery':remnants,'verified':manifest['verified'],'parity':manifest['parity'],'materialized_tree_hash':manifest['materialized_tree_hash'],'materialized_tree_hash_scope':manifest['materialized_tree_hash_scope'],'staged_vs_recovered_files':shared,'elapsed_seconds':round(time.monotonic()-start,3)}
 (out/'result.json').write_text(json.dumps(final,indent=2));print(json.dumps(final,indent=2))
