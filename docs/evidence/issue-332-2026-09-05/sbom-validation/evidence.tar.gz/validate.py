from __future__ import annotations

import hashlib
import copy
import importlib.metadata
import json
from pathlib import Path
from urllib.parse import urldefrag

import jsonschema
from referencing import Registry, Resource

root = Path(__file__).resolve().parent
urls = json.loads((root / 'schema-urls.json').read_text())
schemas = []
for name, url in urls.items():
    path = root / f'{name}.schema.json'
    schemas.append((url, path))
for record in json.loads((root / 'schema-references.json').read_text()):
    schemas.append((record['url'], root / record['file']))
registry = Registry()
records = []
formats = set()
external_refs = set()
def inspect(value):
    if isinstance(value, dict):
        if isinstance(value.get('format'), str):
            formats.add(value['format'])
        if isinstance(value.get('$ref'), str) and not value['$ref'].startswith('#'):
            external_refs.add(value['$ref'])
        for item in value.values():
            inspect(item)
    elif isinstance(value, list):
        for item in value:
            inspect(item)
for url, path in schemas:
    raw = path.read_bytes()
    schema = json.loads(raw)
    validator_type = jsonschema.validators.validator_for(schema)
    validator_type.check_schema(schema)
    resource = Resource.from_contents(schema)
    identity = schema.get('$id', schema.get('id'))
    registry = registry.with_resource(url, resource)
    if identity:
        registry = registry.with_resource(urldefrag(identity)[0], resource)
    inspect(schema)
    records.append({'file': path.name, 'url': url, 'id': identity,
                    'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw),
                    'validator': validator_type.__name__})
checker = jsonschema.FormatChecker()
missing_formats = sorted(formats - checker.checkers.keys())
if missing_formats:
    raise RuntimeError(f'Format validators absent: {missing_formats}')
results = []
for name in ('requests', 'packaging'):
    for kind in ('spdx', 'cyclonedx'):
        path = root / f'{name}-{kind}.json'
        raw = path.read_bytes()
        document = json.loads(raw)
        schema = json.loads((root / f'{kind}.schema.json').read_text())
        validator_type = jsonschema.validators.validator_for(schema)
        validator = validator_type(schema, registry=registry, format_checker=checker)
        errors = sorted(validator.iter_errors(document), key=lambda error: str(list(error.absolute_path)))
        results.append({'file': path.name, 'sha256': hashlib.sha256(raw).hexdigest(),
                        'declared_version': document.get('spdxVersion', document.get('specVersion')),
                        'packages': len(document.get('packages', document.get('components', []))),
                        'valid': not errors,
                        'errors': [{'path': list(error.absolute_path), 'schema_path': list(error.absolute_schema_path),
                                    'message': error.message} for error in errors]})
negative_results = []
for kind in ('spdx', 'cyclonedx'):
    document = copy.deepcopy(json.loads((root / f'requests-{kind}.json').read_text()))
    if kind == 'spdx':
        package = next(item for item in document['packages'] if item['externalRefs'])
        package['externalRefs'][0]['referenceCategory'] = 'INVALID-CATEGORY'
    else:
        component = next(item for item in document['components'] if item['licenses'])
        component['licenses'] = [{'license': {'id': 'Invalid-License-Not-In-Official-List'}}]
    path = root / f'requests-{kind}-altered.json'
    path.write_text(json.dumps(document, indent=2, sort_keys=True) + '\n')
    schema = json.loads((root / f'{kind}.schema.json').read_text())
    validator = jsonschema.validators.validator_for(schema)(schema, registry=registry, format_checker=checker)
    errors = sorted(validator.iter_errors(document), key=lambda error: str(list(error.absolute_path)))
    negative_results.append({'file': path.name, 'rejected': bool(errors),
        'errors': [{'path': list(error.absolute_path), 'message': error.message} for error in errors]})
result = {'negative_results': negative_results, 'schemas': records, 'external_schema_references': sorted(external_refs),
          'format_validators_checked': sorted(formats), 'missing_format_validators': missing_formats,
          'versions': {name: importlib.metadata.version(name) for name in ('jsonschema', 'referencing')},
          'results': results,
          'limitations': 'JSON Schema validation proves conformance to the downloaded official versioned schemas, not semantic correctness or complete dependency graph coverage. No schema edits or relaxed format/ref checks. Validation runs without network; all external resources are unchanged official files registered under their declared IDs.'}
(root / 'validation-results.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps(result, indent=2, sort_keys=True))
raise SystemExit(0 if all(item['valid'] for item in results) and all(item['rejected'] for item in negative_results) else 1)
