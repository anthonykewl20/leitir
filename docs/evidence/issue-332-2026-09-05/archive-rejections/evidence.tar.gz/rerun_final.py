from __future__ import annotations
from pathlib import Path
import hashlib,json,os,subprocess,zipfile
B=Path('/tmp/leitir-remediation-20260905');W=B/'release-0.2.000';D=B/'release-evidence/ci-artifact-reject-review';env={k:v for k,v in os.environ.items() if k not in {'GH_TOKEN','GITHUB_TOKEN'}}
records=json.loads((D/'results.json').read_text())+json.loads((D/'additional-results.json').read_text())+[json.loads((D/'zlib-result.json').read_text())]+json.loads((D/'trailer-results.json').read_text())+[json.loads((D/'duplicate-payload-before.json').read_text())]
rows=[]
for before in records:
 command=before['command'];case=Path(command[command.index('--dist')+1]);actual={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(case.iterdir())};expected=before.get('artifact_sha256')
 if expected is not None:assert actual==expected,(before['case'],'mutated input changed')
 elif 'archive_sha256' in before:assert actual['leitir-0.2.0.tar.gz']==before['archive_sha256']
 elif 'sha256' in before:assert actual['leitir-0.2.0-py3-none-any.whl']==before['sha256']
 else:assert actual==json.loads(before['stdout'])['sha256']
 p=subprocess.run(command,cwd=W,env=env,capture_output=True,text=True,timeout=30);row={'case':before['case'],'command':command,'before_exit':before['returncode'],'after_exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'artifact_sha256':actual};rows.append(row)
 valid=before['case'] in {'control_original','wheel_bad_crc'}
 assert p.returncode==(0 if valid else 1) and 'Traceback' not in p.stderr,row
 assert valid or p.stderr.startswith('release verification rejected:'),row
(D/'final-results.json').write_text(json.dumps(rows,indent=2))
archive=D/'wheel_duplicate_payload/leitir-0.2.0-py3-none-any.whl';members=[]
with zipfile.ZipFile(archive) as z:
 for i,item in enumerate([x for x in z.infolist() if x.filename=='leitir/__init__.py']):
  try:
   data=z.read(item);record={'index':i,'header_offset':item.header_offset,'readable':True,'sha256':hashlib.sha256(data).hexdigest()}
  except zipfile.BadZipFile as exc:record={'index':i,'header_offset':item.header_offset,'readable':False,'error':str(exc)}
  members.append(record)
 named_validation=z.testzip()
assert len(members)==2 and not members[0]['readable'] and members[1]['readable'] and named_validation is None
(D/'duplicate-independent-validation.json').write_text(json.dumps({'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':members,'name_based_testzip_result':named_validation,'final_cli_reject':rows[-1]},indent=2))
identities={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip(),'tool_sha256':hashlib.sha256((W/'tools/verify_release.py').read_bytes()).hexdigest(),'project_sha256':hashlib.sha256((W/'pyproject.toml').read_bytes()).hexdigest(),'source_state':'Root uncommitted full verifier corrections, including duplicate wheel paths','total_commands':len(rows),'clean_rejections':sum(x['after_exit']==1 for x in rows),'valid_acceptances':sum(x['after_exit']==0 for x in rows)}
(D/'final-identities.json').write_text(json.dumps(identities,indent=2));print(json.dumps(identities,indent=2))
