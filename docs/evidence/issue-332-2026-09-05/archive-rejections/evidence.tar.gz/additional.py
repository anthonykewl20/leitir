from __future__ import annotations
from pathlib import Path
import copy,hashlib,io,json,os,shutil,subprocess,tarfile,zipfile
B=Path('/tmp/leitir-remediation-20260905');W=B/'release-0.2.000';D=B/'release-evidence/ci-artifact-reject-review';O=B/'release-evidence/ci-33962193988-dist';N='leitir-0.2.0-py3-none-any.whl';T='leitir-0.2.0.tar.gz';rows=[]
for kind in ['wheel_corrupt_payload','sdist_project_table_absent']:
 d=D/kind;d.mkdir()
 for n in [N,T]:shutil.copyfile(O/n,d/n)
 validation=None
 if kind=='wheel_corrupt_payload':
  with zipfile.ZipFile(d/N) as z: info=z.getinfo('leitir/__init__.py');offset=info.header_offset+30+len(info.filename.encode())+len(info.extra)+info.compress_size//2
  data=bytearray((d/N).read_bytes());data[offset]^=128;(d/N).write_bytes(data)
  try:
   with zipfile.ZipFile(d/N) as z:z.read('leitir/__init__.py')
  except Exception as e:validation={'type':type(e).__name__,'message':str(e)}
  assert validation is not None, 'Must demonstrate actual corrupt member before testing verifier'
 else:
  with tarfile.open(O/T,'r:gz') as src,tarfile.open(d/T,'w:gz') as dst:
   for member in src.getmembers():
    member=copy.copy(member);data=src.extractfile(member).read() if member.isfile() else None
    if member.name=='leitir-0.2.0/pyproject.toml':data=b'[build-system]\nrequires = []\n';member.size=len(data)
    dst.addfile(member,io.BytesIO(data) if data is not None else None)
 command=['python',str(W/'tools/verify_release.py'),'--tag','v0.2.000','--dist',str(d),'--project',str(W/'pyproject.toml')]
 p=subprocess.run(command,cwd=W,env={k:v for k,v in os.environ.items() if k not in {'GH_TOKEN','GITHUB_TOKEN'}},capture_output=True,text=True,timeout=30)
 rows.append({'case':kind,'command':command,'independent_zip_read_error':validation,'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'artifact_sha256':{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in d.iterdir()}})
(D/'additional-results.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows,indent=2))
