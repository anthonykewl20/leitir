# Actual CI distribution validation

CI run33962193988 built these exact downloaded artifacts at Git headcc134194e6528c34dd364d8a1dae15939093ed16. No replacement artifacts were built. The production verifier extracted from that head accepts publicv0.2.000 and normalized distribution0.2.0. See verify-release.stdout for artifact SHA256 identities.

Every packaged tracked source/data file matches exact Git bytes:127 in the wheel and326 in the sdist. All119 tracked runtimePython files are present in each. source-byte-comparison.json records every path and digest, and separately lists generated packaging metadata.

Each archive was installed independently in its own uv environment with no runtime dependencies and no source PYTHONPATH. Installing the source distribution performs its normal installer build; it does not replace the downloaded publication artifact. Both installed CLIs report leitir0.2.000 while distribution metadata reports0.2.0. Both successfully materialize pinned Packaging, produce source-backed info, and extract462 AST API symbols. The downloaded version.py matches an independent raw.githubusercontent.com read at that exact pin, Git blob46bc2613086732e34b8863b7ea562ffb6918865b.

commands.json records14 successful environment/install/version/metadata/live commands. Raw stdout/stderr are preserved with credentials removed. summary.json contains the principal results. A probe-driver assumption initially looked for an API results envelope; the CLI correctly returned its documented direct API object. The assertion was corrected and the original successful API output retained; no application command failed.

This validates these actual CI artifacts and the exercised real upstream path. Workflow/review completion and final release publication are recorded separately after required CI and CodeQL pass. No claim about unexecuted behavior or exhaustive absence of defects is implied.
